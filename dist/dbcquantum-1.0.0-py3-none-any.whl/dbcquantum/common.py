from typing import TypeAlias

QubitSpecifier: TypeAlias = int
QubitMapping: TypeAlias = list[QubitSpecifier]
